﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models
{
    public partial class OrderUser
    {
        public int? Id { get; set; }
        public int? TypeDelivery { get; set; }
        public string? Address { get; set; }
        public int? IdUsers { get; set; }
        public bool? IsDeleted { get; set; }
        public string? Status { get; set; }
    }
}
