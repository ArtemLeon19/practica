﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models
{
    public partial class Cart
    {
        public int? IdOrder { get; set; }
        public int? IdProduct { get; set; }
        public int? Amount { get; set; }
        public int? TotalCost { get; set; }
        public bool? IsDeleted { get; set; }
    }
}
