﻿using DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models.Repositories
{
    public abstract class RepositoryBase<T> : IRepositoryBase<T> where T : class
    {
        protected PracticaContext Repository { get; set; }
        public RepositoryBase(PracticaContext repositoryContext)
        {
            Repository = repositoryContext;
        }
        public IQueryable<T> FindAll() => Repository.Set<T>().AsNoTracking();
        public IQueryable<T> FindByCondition(Expression<Func<T,bool>> expression) =>
            Repository.Set<T>().Where(expression).AsNoTracking();
        public void Create(T entity) => Repository.Set<T>().Add(entity);
        public void Update(T entity) => Repository.Set<T>().Update(entity);
        public void Delete(T entity) => Repository.Set<T>().Remove(entity);
    }
}
