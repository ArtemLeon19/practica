﻿using DataAccess.Interfaces;
using DataAccess.SQL;
using DataAccess.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Wrapper
{
    public class RepositoryWrapper : IRepositoryWrapper
    {
        private PracticaContext _repoContext;
        private IUserRepository _user;
        public IUserRepository UserRepository
        { 
            get 
            { 
                if (_user == null)
                {
                    _user = new UserRepository(_repoContext);
                }
                return _user;
            } 
        }
        public RepositoryWrapper(PracticaContext repoContext)
        {
            _repoContext = repoContext;
        }
        public void Save()
        {
            _repoContext.SaveChanges();
        }
    }
}
